# Keep WebView JS interfaces if added in future versions
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
