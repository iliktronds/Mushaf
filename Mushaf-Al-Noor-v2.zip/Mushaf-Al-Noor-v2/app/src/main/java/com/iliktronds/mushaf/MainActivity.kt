package com.iliktronds.mushaf

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.URL
import java.util.Calendar
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    private val LIVE_WEB_URL = "https://iliktronds.github.io/Mushaf/"
    private val LOCAL_WEB_URL = "file:///android_asset/www/index.html"
    private val VERSION_CHECK_URL = "https://raw.githubusercontent.com/iliktronds/Mushaf/main/version.json"
    private val CURRENT_VERSION_CODE = 2

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        requestAppPermissions()
        setupWebView()
        checkForApkUpdate()

        if (isOnline()) {
            webView.loadUrl(LIVE_WEB_URL)
        } else {
            webView.loadUrl(LOCAL_WEB_URL)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.allowFileAccess = true
        settings.cacheMode = if (isOnline()) WebSettings.LOAD_DEFAULT else WebSettings.LOAD_CACHE_ELSE_NETWORK

        webView.addJavascriptInterface(AndroidBridge(this), "AndroidBridge")

        webView.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(
                origin: String,
                callback: GeolocationPermissions.Callback
            ) {
                callback.invoke(origin, true, false)
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) {
                    webView.loadUrl(LOCAL_WEB_URL)
                }
            }
        }
    }

    private fun requestAppPermissions() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 101)
        }
    }

    private fun isOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun checkForApkUpdate() {
        if (!isOnline()) return
        thread {
            try {
                val jsonText = URL(VERSION_CHECK_URL).readText()
                val obj = JSONObject(jsonText)
                val latestCode = obj.getInt("versionCode")
                val apkUrl = obj.getString("apkUrl")
                val notes = obj.optString("notes", "تحديث جديد متوفر لتحسين الأداء.")

                if (latestCode > CURRENT_VERSION_CODE) {
                    runOnUiThread {
                        AlertDialog.Builder(this)
                            .setTitle("تحديث جديد متوفر لمصحف النور")
                            .setMessage(notes)
                            .setPositiveButton("تحديث الآن") { _, _ ->
                                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(apkUrl)))
                            }
                            .setNegativeButton("لاحقاً", null)
                            .show()
                    }
                }
            } catch (_: Exception) {}
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    class AndroidBridge(private val context: Context) {
        @JavascriptInterface
        fun setAdhanVoice(voiceUrl: String) {
            val prefs = context.getSharedPreferences("mushaf_prefs", Context.MODE_PRIVATE)
            prefs.edit().putString("adhan_voice", voiceUrl).apply()
        }

        @JavascriptInterface
        fun scheduleAdhan(lat: Double, lng: Double, voiceUrl: String) {
            setAdhanVoice(voiceUrl)
            thread {
                try {
                    val api = "https://api.aladhan.com/v1/timings?latitude=$lat&longitude=$lng&method=21"
                    val json = JSONObject(URL(api).readText())
                    val timings = json.getJSONObject("data").getJSONObject("timings")
                    val prayers = mapOf(
                        1 to Pair("الفجر", timings.getString("Fajr")),
                        2 to Pair("الظهر", timings.getString("Dhuhr")),
                        3 to Pair("العصر", timings.getString("Asr")),
                        4 to Pair("المغرب", timings.getString("Maghrib")),
                        5 to Pair("العشاء", timings.getString("Isha"))
                    )
                    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

                    for ((id, pair) in prayers) {
                        val parts = pair.second.split(" ")[0].split(":")
                        val cal = Calendar.getInstance().apply {
                            set(Calendar.HOUR_OF_DAY, parts[0].toInt())
                            set(Calendar.MINUTE, parts[1].toInt())
                            set(Calendar.SECOND, 0)
                            if (before(Calendar.getInstance())) add(Calendar.DAY_OF_YEAR, 1)
                        }
                        val intent = Intent(context, AdhanReceiver::class.java).apply {
                            putExtra("prayer_name", pair.first)
                            putExtra("voice_url", voiceUrl)
                        }
                        val pi = PendingIntent.getBroadcast(
                            context, id, intent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )
                        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                    }
                    (context as? AppCompatActivity)?.runOnUiThread {
                        Toast.makeText(context, "تم تفعيل منبه الأذان للصلوات الخمس بنجاح", Toast.LENGTH_SHORT).show()
                    }
                } catch (_: Exception) {}
            }
        }
    }
}
